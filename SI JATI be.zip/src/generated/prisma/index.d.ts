
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model Chat_history
 * 
 */
export type Chat_history = $Result.DefaultSelection<Prisma.$Chat_historyPayload>
/**
 * Model Faq_manual
 * 
 */
export type Faq_manual = $Result.DefaultSelection<Prisma.$Faq_manualPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Chat_histories
 * const chat_histories = await prisma.chat_history.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Chat_histories
   * const chat_histories = await prisma.chat_history.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.chat_history`: Exposes CRUD operations for the **Chat_history** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Chat_histories
    * const chat_histories = await prisma.chat_history.findMany()
    * ```
    */
  get chat_history(): Prisma.Chat_historyDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.faq_manual`: Exposes CRUD operations for the **Faq_manual** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Faq_manuals
    * const faq_manuals = await prisma.faq_manual.findMany()
    * ```
    */
  get faq_manual(): Prisma.Faq_manualDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.11.1
   * Query Engine version: f40f79ec31188888a2e33acda0ecc8fd10a853a9
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    Chat_history: 'Chat_history',
    Faq_manual: 'Faq_manual'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "chat_history" | "faq_manual"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      Chat_history: {
        payload: Prisma.$Chat_historyPayload<ExtArgs>
        fields: Prisma.Chat_historyFieldRefs
        operations: {
          findUnique: {
            args: Prisma.Chat_historyFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.Chat_historyFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload>
          }
          findFirst: {
            args: Prisma.Chat_historyFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.Chat_historyFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload>
          }
          findMany: {
            args: Prisma.Chat_historyFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload>[]
          }
          create: {
            args: Prisma.Chat_historyCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload>
          }
          createMany: {
            args: Prisma.Chat_historyCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.Chat_historyDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload>
          }
          update: {
            args: Prisma.Chat_historyUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload>
          }
          deleteMany: {
            args: Prisma.Chat_historyDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.Chat_historyUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.Chat_historyUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Chat_historyPayload>
          }
          aggregate: {
            args: Prisma.Chat_historyAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateChat_history>
          }
          groupBy: {
            args: Prisma.Chat_historyGroupByArgs<ExtArgs>
            result: $Utils.Optional<Chat_historyGroupByOutputType>[]
          }
          count: {
            args: Prisma.Chat_historyCountArgs<ExtArgs>
            result: $Utils.Optional<Chat_historyCountAggregateOutputType> | number
          }
        }
      }
      Faq_manual: {
        payload: Prisma.$Faq_manualPayload<ExtArgs>
        fields: Prisma.Faq_manualFieldRefs
        operations: {
          findUnique: {
            args: Prisma.Faq_manualFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.Faq_manualFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload>
          }
          findFirst: {
            args: Prisma.Faq_manualFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.Faq_manualFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload>
          }
          findMany: {
            args: Prisma.Faq_manualFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload>[]
          }
          create: {
            args: Prisma.Faq_manualCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload>
          }
          createMany: {
            args: Prisma.Faq_manualCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.Faq_manualDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload>
          }
          update: {
            args: Prisma.Faq_manualUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload>
          }
          deleteMany: {
            args: Prisma.Faq_manualDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.Faq_manualUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.Faq_manualUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$Faq_manualPayload>
          }
          aggregate: {
            args: Prisma.Faq_manualAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateFaq_manual>
          }
          groupBy: {
            args: Prisma.Faq_manualGroupByArgs<ExtArgs>
            result: $Utils.Optional<Faq_manualGroupByOutputType>[]
          }
          count: {
            args: Prisma.Faq_manualCountArgs<ExtArgs>
            result: $Utils.Optional<Faq_manualCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    chat_history?: Chat_historyOmit
    faq_manual?: Faq_manualOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */



  /**
   * Models
   */

  /**
   * Model Chat_history
   */

  export type AggregateChat_history = {
    _count: Chat_historyCountAggregateOutputType | null
    _min: Chat_historyMinAggregateOutputType | null
    _max: Chat_historyMaxAggregateOutputType | null
  }

  export type Chat_historyMinAggregateOutputType = {
    chat_id: string | null
    user_id: string | null
    user_message: string | null
    retrieved_context: string | null
    bot_response: string | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type Chat_historyMaxAggregateOutputType = {
    chat_id: string | null
    user_id: string | null
    user_message: string | null
    retrieved_context: string | null
    bot_response: string | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type Chat_historyCountAggregateOutputType = {
    chat_id: number
    user_id: number
    user_message: number
    retrieved_context: number
    bot_response: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type Chat_historyMinAggregateInputType = {
    chat_id?: true
    user_id?: true
    user_message?: true
    retrieved_context?: true
    bot_response?: true
    created_at?: true
    updated_at?: true
  }

  export type Chat_historyMaxAggregateInputType = {
    chat_id?: true
    user_id?: true
    user_message?: true
    retrieved_context?: true
    bot_response?: true
    created_at?: true
    updated_at?: true
  }

  export type Chat_historyCountAggregateInputType = {
    chat_id?: true
    user_id?: true
    user_message?: true
    retrieved_context?: true
    bot_response?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type Chat_historyAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Chat_history to aggregate.
     */
    where?: Chat_historyWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Chat_histories to fetch.
     */
    orderBy?: Chat_historyOrderByWithRelationInput | Chat_historyOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: Chat_historyWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Chat_histories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Chat_histories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Chat_histories
    **/
    _count?: true | Chat_historyCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Chat_historyMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Chat_historyMaxAggregateInputType
  }

  export type GetChat_historyAggregateType<T extends Chat_historyAggregateArgs> = {
        [P in keyof T & keyof AggregateChat_history]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateChat_history[P]>
      : GetScalarType<T[P], AggregateChat_history[P]>
  }




  export type Chat_historyGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: Chat_historyWhereInput
    orderBy?: Chat_historyOrderByWithAggregationInput | Chat_historyOrderByWithAggregationInput[]
    by: Chat_historyScalarFieldEnum[] | Chat_historyScalarFieldEnum
    having?: Chat_historyScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Chat_historyCountAggregateInputType | true
    _min?: Chat_historyMinAggregateInputType
    _max?: Chat_historyMaxAggregateInputType
  }

  export type Chat_historyGroupByOutputType = {
    chat_id: string
    user_id: string
    user_message: string
    retrieved_context: string
    bot_response: string
    created_at: Date
    updated_at: Date
    _count: Chat_historyCountAggregateOutputType | null
    _min: Chat_historyMinAggregateOutputType | null
    _max: Chat_historyMaxAggregateOutputType | null
  }

  type GetChat_historyGroupByPayload<T extends Chat_historyGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Chat_historyGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Chat_historyGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Chat_historyGroupByOutputType[P]>
            : GetScalarType<T[P], Chat_historyGroupByOutputType[P]>
        }
      >
    >


  export type Chat_historySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    chat_id?: boolean
    user_id?: boolean
    user_message?: boolean
    retrieved_context?: boolean
    bot_response?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["chat_history"]>



  export type Chat_historySelectScalar = {
    chat_id?: boolean
    user_id?: boolean
    user_message?: boolean
    retrieved_context?: boolean
    bot_response?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type Chat_historyOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"chat_id" | "user_id" | "user_message" | "retrieved_context" | "bot_response" | "created_at" | "updated_at", ExtArgs["result"]["chat_history"]>

  export type $Chat_historyPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Chat_history"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      chat_id: string
      user_id: string
      user_message: string
      retrieved_context: string
      bot_response: string
      created_at: Date
      updated_at: Date
    }, ExtArgs["result"]["chat_history"]>
    composites: {}
  }

  type Chat_historyGetPayload<S extends boolean | null | undefined | Chat_historyDefaultArgs> = $Result.GetResult<Prisma.$Chat_historyPayload, S>

  type Chat_historyCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<Chat_historyFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Chat_historyCountAggregateInputType | true
    }

  export interface Chat_historyDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Chat_history'], meta: { name: 'Chat_history' } }
    /**
     * Find zero or one Chat_history that matches the filter.
     * @param {Chat_historyFindUniqueArgs} args - Arguments to find a Chat_history
     * @example
     * // Get one Chat_history
     * const chat_history = await prisma.chat_history.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends Chat_historyFindUniqueArgs>(args: SelectSubset<T, Chat_historyFindUniqueArgs<ExtArgs>>): Prisma__Chat_historyClient<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Chat_history that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {Chat_historyFindUniqueOrThrowArgs} args - Arguments to find a Chat_history
     * @example
     * // Get one Chat_history
     * const chat_history = await prisma.chat_history.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends Chat_historyFindUniqueOrThrowArgs>(args: SelectSubset<T, Chat_historyFindUniqueOrThrowArgs<ExtArgs>>): Prisma__Chat_historyClient<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Chat_history that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Chat_historyFindFirstArgs} args - Arguments to find a Chat_history
     * @example
     * // Get one Chat_history
     * const chat_history = await prisma.chat_history.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends Chat_historyFindFirstArgs>(args?: SelectSubset<T, Chat_historyFindFirstArgs<ExtArgs>>): Prisma__Chat_historyClient<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Chat_history that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Chat_historyFindFirstOrThrowArgs} args - Arguments to find a Chat_history
     * @example
     * // Get one Chat_history
     * const chat_history = await prisma.chat_history.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends Chat_historyFindFirstOrThrowArgs>(args?: SelectSubset<T, Chat_historyFindFirstOrThrowArgs<ExtArgs>>): Prisma__Chat_historyClient<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Chat_histories that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Chat_historyFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Chat_histories
     * const chat_histories = await prisma.chat_history.findMany()
     * 
     * // Get first 10 Chat_histories
     * const chat_histories = await prisma.chat_history.findMany({ take: 10 })
     * 
     * // Only select the `chat_id`
     * const chat_historyWithChat_idOnly = await prisma.chat_history.findMany({ select: { chat_id: true } })
     * 
     */
    findMany<T extends Chat_historyFindManyArgs>(args?: SelectSubset<T, Chat_historyFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Chat_history.
     * @param {Chat_historyCreateArgs} args - Arguments to create a Chat_history.
     * @example
     * // Create one Chat_history
     * const Chat_history = await prisma.chat_history.create({
     *   data: {
     *     // ... data to create a Chat_history
     *   }
     * })
     * 
     */
    create<T extends Chat_historyCreateArgs>(args: SelectSubset<T, Chat_historyCreateArgs<ExtArgs>>): Prisma__Chat_historyClient<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Chat_histories.
     * @param {Chat_historyCreateManyArgs} args - Arguments to create many Chat_histories.
     * @example
     * // Create many Chat_histories
     * const chat_history = await prisma.chat_history.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends Chat_historyCreateManyArgs>(args?: SelectSubset<T, Chat_historyCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Chat_history.
     * @param {Chat_historyDeleteArgs} args - Arguments to delete one Chat_history.
     * @example
     * // Delete one Chat_history
     * const Chat_history = await prisma.chat_history.delete({
     *   where: {
     *     // ... filter to delete one Chat_history
     *   }
     * })
     * 
     */
    delete<T extends Chat_historyDeleteArgs>(args: SelectSubset<T, Chat_historyDeleteArgs<ExtArgs>>): Prisma__Chat_historyClient<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Chat_history.
     * @param {Chat_historyUpdateArgs} args - Arguments to update one Chat_history.
     * @example
     * // Update one Chat_history
     * const chat_history = await prisma.chat_history.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends Chat_historyUpdateArgs>(args: SelectSubset<T, Chat_historyUpdateArgs<ExtArgs>>): Prisma__Chat_historyClient<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Chat_histories.
     * @param {Chat_historyDeleteManyArgs} args - Arguments to filter Chat_histories to delete.
     * @example
     * // Delete a few Chat_histories
     * const { count } = await prisma.chat_history.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends Chat_historyDeleteManyArgs>(args?: SelectSubset<T, Chat_historyDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Chat_histories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Chat_historyUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Chat_histories
     * const chat_history = await prisma.chat_history.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends Chat_historyUpdateManyArgs>(args: SelectSubset<T, Chat_historyUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Chat_history.
     * @param {Chat_historyUpsertArgs} args - Arguments to update or create a Chat_history.
     * @example
     * // Update or create a Chat_history
     * const chat_history = await prisma.chat_history.upsert({
     *   create: {
     *     // ... data to create a Chat_history
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Chat_history we want to update
     *   }
     * })
     */
    upsert<T extends Chat_historyUpsertArgs>(args: SelectSubset<T, Chat_historyUpsertArgs<ExtArgs>>): Prisma__Chat_historyClient<$Result.GetResult<Prisma.$Chat_historyPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Chat_histories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Chat_historyCountArgs} args - Arguments to filter Chat_histories to count.
     * @example
     * // Count the number of Chat_histories
     * const count = await prisma.chat_history.count({
     *   where: {
     *     // ... the filter for the Chat_histories we want to count
     *   }
     * })
    **/
    count<T extends Chat_historyCountArgs>(
      args?: Subset<T, Chat_historyCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Chat_historyCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Chat_history.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Chat_historyAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Chat_historyAggregateArgs>(args: Subset<T, Chat_historyAggregateArgs>): Prisma.PrismaPromise<GetChat_historyAggregateType<T>>

    /**
     * Group by Chat_history.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Chat_historyGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends Chat_historyGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: Chat_historyGroupByArgs['orderBy'] }
        : { orderBy?: Chat_historyGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, Chat_historyGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetChat_historyGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Chat_history model
   */
  readonly fields: Chat_historyFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Chat_history.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__Chat_historyClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Chat_history model
   */
  interface Chat_historyFieldRefs {
    readonly chat_id: FieldRef<"Chat_history", 'String'>
    readonly user_id: FieldRef<"Chat_history", 'String'>
    readonly user_message: FieldRef<"Chat_history", 'String'>
    readonly retrieved_context: FieldRef<"Chat_history", 'String'>
    readonly bot_response: FieldRef<"Chat_history", 'String'>
    readonly created_at: FieldRef<"Chat_history", 'DateTime'>
    readonly updated_at: FieldRef<"Chat_history", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Chat_history findUnique
   */
  export type Chat_historyFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * Filter, which Chat_history to fetch.
     */
    where: Chat_historyWhereUniqueInput
  }

  /**
   * Chat_history findUniqueOrThrow
   */
  export type Chat_historyFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * Filter, which Chat_history to fetch.
     */
    where: Chat_historyWhereUniqueInput
  }

  /**
   * Chat_history findFirst
   */
  export type Chat_historyFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * Filter, which Chat_history to fetch.
     */
    where?: Chat_historyWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Chat_histories to fetch.
     */
    orderBy?: Chat_historyOrderByWithRelationInput | Chat_historyOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Chat_histories.
     */
    cursor?: Chat_historyWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Chat_histories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Chat_histories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Chat_histories.
     */
    distinct?: Chat_historyScalarFieldEnum | Chat_historyScalarFieldEnum[]
  }

  /**
   * Chat_history findFirstOrThrow
   */
  export type Chat_historyFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * Filter, which Chat_history to fetch.
     */
    where?: Chat_historyWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Chat_histories to fetch.
     */
    orderBy?: Chat_historyOrderByWithRelationInput | Chat_historyOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Chat_histories.
     */
    cursor?: Chat_historyWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Chat_histories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Chat_histories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Chat_histories.
     */
    distinct?: Chat_historyScalarFieldEnum | Chat_historyScalarFieldEnum[]
  }

  /**
   * Chat_history findMany
   */
  export type Chat_historyFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * Filter, which Chat_histories to fetch.
     */
    where?: Chat_historyWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Chat_histories to fetch.
     */
    orderBy?: Chat_historyOrderByWithRelationInput | Chat_historyOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Chat_histories.
     */
    cursor?: Chat_historyWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Chat_histories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Chat_histories.
     */
    skip?: number
    distinct?: Chat_historyScalarFieldEnum | Chat_historyScalarFieldEnum[]
  }

  /**
   * Chat_history create
   */
  export type Chat_historyCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * The data needed to create a Chat_history.
     */
    data: XOR<Chat_historyCreateInput, Chat_historyUncheckedCreateInput>
  }

  /**
   * Chat_history createMany
   */
  export type Chat_historyCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Chat_histories.
     */
    data: Chat_historyCreateManyInput | Chat_historyCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Chat_history update
   */
  export type Chat_historyUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * The data needed to update a Chat_history.
     */
    data: XOR<Chat_historyUpdateInput, Chat_historyUncheckedUpdateInput>
    /**
     * Choose, which Chat_history to update.
     */
    where: Chat_historyWhereUniqueInput
  }

  /**
   * Chat_history updateMany
   */
  export type Chat_historyUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Chat_histories.
     */
    data: XOR<Chat_historyUpdateManyMutationInput, Chat_historyUncheckedUpdateManyInput>
    /**
     * Filter which Chat_histories to update
     */
    where?: Chat_historyWhereInput
    /**
     * Limit how many Chat_histories to update.
     */
    limit?: number
  }

  /**
   * Chat_history upsert
   */
  export type Chat_historyUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * The filter to search for the Chat_history to update in case it exists.
     */
    where: Chat_historyWhereUniqueInput
    /**
     * In case the Chat_history found by the `where` argument doesn't exist, create a new Chat_history with this data.
     */
    create: XOR<Chat_historyCreateInput, Chat_historyUncheckedCreateInput>
    /**
     * In case the Chat_history was found with the provided `where` argument, update it with this data.
     */
    update: XOR<Chat_historyUpdateInput, Chat_historyUncheckedUpdateInput>
  }

  /**
   * Chat_history delete
   */
  export type Chat_historyDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
    /**
     * Filter which Chat_history to delete.
     */
    where: Chat_historyWhereUniqueInput
  }

  /**
   * Chat_history deleteMany
   */
  export type Chat_historyDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Chat_histories to delete
     */
    where?: Chat_historyWhereInput
    /**
     * Limit how many Chat_histories to delete.
     */
    limit?: number
  }

  /**
   * Chat_history without action
   */
  export type Chat_historyDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Chat_history
     */
    select?: Chat_historySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Chat_history
     */
    omit?: Chat_historyOmit<ExtArgs> | null
  }


  /**
   * Model Faq_manual
   */

  export type AggregateFaq_manual = {
    _count: Faq_manualCountAggregateOutputType | null
    _min: Faq_manualMinAggregateOutputType | null
    _max: Faq_manualMaxAggregateOutputType | null
  }

  export type Faq_manualMinAggregateOutputType = {
    faq_id: string | null
    question: string | null
    answer: string | null
    kategori: string | null
    reference: string | null
    user_id: string | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type Faq_manualMaxAggregateOutputType = {
    faq_id: string | null
    question: string | null
    answer: string | null
    kategori: string | null
    reference: string | null
    user_id: string | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type Faq_manualCountAggregateOutputType = {
    faq_id: number
    question: number
    answer: number
    kategori: number
    reference: number
    user_id: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type Faq_manualMinAggregateInputType = {
    faq_id?: true
    question?: true
    answer?: true
    kategori?: true
    reference?: true
    user_id?: true
    created_at?: true
    updated_at?: true
  }

  export type Faq_manualMaxAggregateInputType = {
    faq_id?: true
    question?: true
    answer?: true
    kategori?: true
    reference?: true
    user_id?: true
    created_at?: true
    updated_at?: true
  }

  export type Faq_manualCountAggregateInputType = {
    faq_id?: true
    question?: true
    answer?: true
    kategori?: true
    reference?: true
    user_id?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type Faq_manualAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Faq_manual to aggregate.
     */
    where?: Faq_manualWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Faq_manuals to fetch.
     */
    orderBy?: Faq_manualOrderByWithRelationInput | Faq_manualOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: Faq_manualWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Faq_manuals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Faq_manuals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Faq_manuals
    **/
    _count?: true | Faq_manualCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Faq_manualMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Faq_manualMaxAggregateInputType
  }

  export type GetFaq_manualAggregateType<T extends Faq_manualAggregateArgs> = {
        [P in keyof T & keyof AggregateFaq_manual]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateFaq_manual[P]>
      : GetScalarType<T[P], AggregateFaq_manual[P]>
  }




  export type Faq_manualGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: Faq_manualWhereInput
    orderBy?: Faq_manualOrderByWithAggregationInput | Faq_manualOrderByWithAggregationInput[]
    by: Faq_manualScalarFieldEnum[] | Faq_manualScalarFieldEnum
    having?: Faq_manualScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Faq_manualCountAggregateInputType | true
    _min?: Faq_manualMinAggregateInputType
    _max?: Faq_manualMaxAggregateInputType
  }

  export type Faq_manualGroupByOutputType = {
    faq_id: string
    question: string
    answer: string
    kategori: string
    reference: string
    user_id: string
    created_at: Date
    updated_at: Date
    _count: Faq_manualCountAggregateOutputType | null
    _min: Faq_manualMinAggregateOutputType | null
    _max: Faq_manualMaxAggregateOutputType | null
  }

  type GetFaq_manualGroupByPayload<T extends Faq_manualGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Faq_manualGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Faq_manualGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Faq_manualGroupByOutputType[P]>
            : GetScalarType<T[P], Faq_manualGroupByOutputType[P]>
        }
      >
    >


  export type Faq_manualSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    faq_id?: boolean
    question?: boolean
    answer?: boolean
    kategori?: boolean
    reference?: boolean
    user_id?: boolean
    created_at?: boolean
    updated_at?: boolean
  }, ExtArgs["result"]["faq_manual"]>



  export type Faq_manualSelectScalar = {
    faq_id?: boolean
    question?: boolean
    answer?: boolean
    kategori?: boolean
    reference?: boolean
    user_id?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type Faq_manualOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"faq_id" | "question" | "answer" | "kategori" | "reference" | "user_id" | "created_at" | "updated_at", ExtArgs["result"]["faq_manual"]>

  export type $Faq_manualPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Faq_manual"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      faq_id: string
      question: string
      answer: string
      kategori: string
      reference: string
      user_id: string
      created_at: Date
      updated_at: Date
    }, ExtArgs["result"]["faq_manual"]>
    composites: {}
  }

  type Faq_manualGetPayload<S extends boolean | null | undefined | Faq_manualDefaultArgs> = $Result.GetResult<Prisma.$Faq_manualPayload, S>

  type Faq_manualCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<Faq_manualFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Faq_manualCountAggregateInputType | true
    }

  export interface Faq_manualDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Faq_manual'], meta: { name: 'Faq_manual' } }
    /**
     * Find zero or one Faq_manual that matches the filter.
     * @param {Faq_manualFindUniqueArgs} args - Arguments to find a Faq_manual
     * @example
     * // Get one Faq_manual
     * const faq_manual = await prisma.faq_manual.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends Faq_manualFindUniqueArgs>(args: SelectSubset<T, Faq_manualFindUniqueArgs<ExtArgs>>): Prisma__Faq_manualClient<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Faq_manual that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {Faq_manualFindUniqueOrThrowArgs} args - Arguments to find a Faq_manual
     * @example
     * // Get one Faq_manual
     * const faq_manual = await prisma.faq_manual.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends Faq_manualFindUniqueOrThrowArgs>(args: SelectSubset<T, Faq_manualFindUniqueOrThrowArgs<ExtArgs>>): Prisma__Faq_manualClient<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Faq_manual that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Faq_manualFindFirstArgs} args - Arguments to find a Faq_manual
     * @example
     * // Get one Faq_manual
     * const faq_manual = await prisma.faq_manual.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends Faq_manualFindFirstArgs>(args?: SelectSubset<T, Faq_manualFindFirstArgs<ExtArgs>>): Prisma__Faq_manualClient<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Faq_manual that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Faq_manualFindFirstOrThrowArgs} args - Arguments to find a Faq_manual
     * @example
     * // Get one Faq_manual
     * const faq_manual = await prisma.faq_manual.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends Faq_manualFindFirstOrThrowArgs>(args?: SelectSubset<T, Faq_manualFindFirstOrThrowArgs<ExtArgs>>): Prisma__Faq_manualClient<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Faq_manuals that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Faq_manualFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Faq_manuals
     * const faq_manuals = await prisma.faq_manual.findMany()
     * 
     * // Get first 10 Faq_manuals
     * const faq_manuals = await prisma.faq_manual.findMany({ take: 10 })
     * 
     * // Only select the `faq_id`
     * const faq_manualWithFaq_idOnly = await prisma.faq_manual.findMany({ select: { faq_id: true } })
     * 
     */
    findMany<T extends Faq_manualFindManyArgs>(args?: SelectSubset<T, Faq_manualFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Faq_manual.
     * @param {Faq_manualCreateArgs} args - Arguments to create a Faq_manual.
     * @example
     * // Create one Faq_manual
     * const Faq_manual = await prisma.faq_manual.create({
     *   data: {
     *     // ... data to create a Faq_manual
     *   }
     * })
     * 
     */
    create<T extends Faq_manualCreateArgs>(args: SelectSubset<T, Faq_manualCreateArgs<ExtArgs>>): Prisma__Faq_manualClient<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Faq_manuals.
     * @param {Faq_manualCreateManyArgs} args - Arguments to create many Faq_manuals.
     * @example
     * // Create many Faq_manuals
     * const faq_manual = await prisma.faq_manual.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends Faq_manualCreateManyArgs>(args?: SelectSubset<T, Faq_manualCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Faq_manual.
     * @param {Faq_manualDeleteArgs} args - Arguments to delete one Faq_manual.
     * @example
     * // Delete one Faq_manual
     * const Faq_manual = await prisma.faq_manual.delete({
     *   where: {
     *     // ... filter to delete one Faq_manual
     *   }
     * })
     * 
     */
    delete<T extends Faq_manualDeleteArgs>(args: SelectSubset<T, Faq_manualDeleteArgs<ExtArgs>>): Prisma__Faq_manualClient<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Faq_manual.
     * @param {Faq_manualUpdateArgs} args - Arguments to update one Faq_manual.
     * @example
     * // Update one Faq_manual
     * const faq_manual = await prisma.faq_manual.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends Faq_manualUpdateArgs>(args: SelectSubset<T, Faq_manualUpdateArgs<ExtArgs>>): Prisma__Faq_manualClient<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Faq_manuals.
     * @param {Faq_manualDeleteManyArgs} args - Arguments to filter Faq_manuals to delete.
     * @example
     * // Delete a few Faq_manuals
     * const { count } = await prisma.faq_manual.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends Faq_manualDeleteManyArgs>(args?: SelectSubset<T, Faq_manualDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Faq_manuals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Faq_manualUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Faq_manuals
     * const faq_manual = await prisma.faq_manual.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends Faq_manualUpdateManyArgs>(args: SelectSubset<T, Faq_manualUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Faq_manual.
     * @param {Faq_manualUpsertArgs} args - Arguments to update or create a Faq_manual.
     * @example
     * // Update or create a Faq_manual
     * const faq_manual = await prisma.faq_manual.upsert({
     *   create: {
     *     // ... data to create a Faq_manual
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Faq_manual we want to update
     *   }
     * })
     */
    upsert<T extends Faq_manualUpsertArgs>(args: SelectSubset<T, Faq_manualUpsertArgs<ExtArgs>>): Prisma__Faq_manualClient<$Result.GetResult<Prisma.$Faq_manualPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Faq_manuals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Faq_manualCountArgs} args - Arguments to filter Faq_manuals to count.
     * @example
     * // Count the number of Faq_manuals
     * const count = await prisma.faq_manual.count({
     *   where: {
     *     // ... the filter for the Faq_manuals we want to count
     *   }
     * })
    **/
    count<T extends Faq_manualCountArgs>(
      args?: Subset<T, Faq_manualCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Faq_manualCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Faq_manual.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Faq_manualAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Faq_manualAggregateArgs>(args: Subset<T, Faq_manualAggregateArgs>): Prisma.PrismaPromise<GetFaq_manualAggregateType<T>>

    /**
     * Group by Faq_manual.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Faq_manualGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends Faq_manualGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: Faq_manualGroupByArgs['orderBy'] }
        : { orderBy?: Faq_manualGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, Faq_manualGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFaq_manualGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Faq_manual model
   */
  readonly fields: Faq_manualFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Faq_manual.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__Faq_manualClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Faq_manual model
   */
  interface Faq_manualFieldRefs {
    readonly faq_id: FieldRef<"Faq_manual", 'String'>
    readonly question: FieldRef<"Faq_manual", 'String'>
    readonly answer: FieldRef<"Faq_manual", 'String'>
    readonly kategori: FieldRef<"Faq_manual", 'String'>
    readonly reference: FieldRef<"Faq_manual", 'String'>
    readonly user_id: FieldRef<"Faq_manual", 'String'>
    readonly created_at: FieldRef<"Faq_manual", 'DateTime'>
    readonly updated_at: FieldRef<"Faq_manual", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Faq_manual findUnique
   */
  export type Faq_manualFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * Filter, which Faq_manual to fetch.
     */
    where: Faq_manualWhereUniqueInput
  }

  /**
   * Faq_manual findUniqueOrThrow
   */
  export type Faq_manualFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * Filter, which Faq_manual to fetch.
     */
    where: Faq_manualWhereUniqueInput
  }

  /**
   * Faq_manual findFirst
   */
  export type Faq_manualFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * Filter, which Faq_manual to fetch.
     */
    where?: Faq_manualWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Faq_manuals to fetch.
     */
    orderBy?: Faq_manualOrderByWithRelationInput | Faq_manualOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Faq_manuals.
     */
    cursor?: Faq_manualWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Faq_manuals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Faq_manuals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Faq_manuals.
     */
    distinct?: Faq_manualScalarFieldEnum | Faq_manualScalarFieldEnum[]
  }

  /**
   * Faq_manual findFirstOrThrow
   */
  export type Faq_manualFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * Filter, which Faq_manual to fetch.
     */
    where?: Faq_manualWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Faq_manuals to fetch.
     */
    orderBy?: Faq_manualOrderByWithRelationInput | Faq_manualOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Faq_manuals.
     */
    cursor?: Faq_manualWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Faq_manuals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Faq_manuals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Faq_manuals.
     */
    distinct?: Faq_manualScalarFieldEnum | Faq_manualScalarFieldEnum[]
  }

  /**
   * Faq_manual findMany
   */
  export type Faq_manualFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * Filter, which Faq_manuals to fetch.
     */
    where?: Faq_manualWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Faq_manuals to fetch.
     */
    orderBy?: Faq_manualOrderByWithRelationInput | Faq_manualOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Faq_manuals.
     */
    cursor?: Faq_manualWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Faq_manuals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Faq_manuals.
     */
    skip?: number
    distinct?: Faq_manualScalarFieldEnum | Faq_manualScalarFieldEnum[]
  }

  /**
   * Faq_manual create
   */
  export type Faq_manualCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * The data needed to create a Faq_manual.
     */
    data: XOR<Faq_manualCreateInput, Faq_manualUncheckedCreateInput>
  }

  /**
   * Faq_manual createMany
   */
  export type Faq_manualCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Faq_manuals.
     */
    data: Faq_manualCreateManyInput | Faq_manualCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Faq_manual update
   */
  export type Faq_manualUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * The data needed to update a Faq_manual.
     */
    data: XOR<Faq_manualUpdateInput, Faq_manualUncheckedUpdateInput>
    /**
     * Choose, which Faq_manual to update.
     */
    where: Faq_manualWhereUniqueInput
  }

  /**
   * Faq_manual updateMany
   */
  export type Faq_manualUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Faq_manuals.
     */
    data: XOR<Faq_manualUpdateManyMutationInput, Faq_manualUncheckedUpdateManyInput>
    /**
     * Filter which Faq_manuals to update
     */
    where?: Faq_manualWhereInput
    /**
     * Limit how many Faq_manuals to update.
     */
    limit?: number
  }

  /**
   * Faq_manual upsert
   */
  export type Faq_manualUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * The filter to search for the Faq_manual to update in case it exists.
     */
    where: Faq_manualWhereUniqueInput
    /**
     * In case the Faq_manual found by the `where` argument doesn't exist, create a new Faq_manual with this data.
     */
    create: XOR<Faq_manualCreateInput, Faq_manualUncheckedCreateInput>
    /**
     * In case the Faq_manual was found with the provided `where` argument, update it with this data.
     */
    update: XOR<Faq_manualUpdateInput, Faq_manualUncheckedUpdateInput>
  }

  /**
   * Faq_manual delete
   */
  export type Faq_manualDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
    /**
     * Filter which Faq_manual to delete.
     */
    where: Faq_manualWhereUniqueInput
  }

  /**
   * Faq_manual deleteMany
   */
  export type Faq_manualDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Faq_manuals to delete
     */
    where?: Faq_manualWhereInput
    /**
     * Limit how many Faq_manuals to delete.
     */
    limit?: number
  }

  /**
   * Faq_manual without action
   */
  export type Faq_manualDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Faq_manual
     */
    select?: Faq_manualSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Faq_manual
     */
    omit?: Faq_manualOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const Chat_historyScalarFieldEnum: {
    chat_id: 'chat_id',
    user_id: 'user_id',
    user_message: 'user_message',
    retrieved_context: 'retrieved_context',
    bot_response: 'bot_response',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type Chat_historyScalarFieldEnum = (typeof Chat_historyScalarFieldEnum)[keyof typeof Chat_historyScalarFieldEnum]


  export const Faq_manualScalarFieldEnum: {
    faq_id: 'faq_id',
    question: 'question',
    answer: 'answer',
    kategori: 'kategori',
    reference: 'reference',
    user_id: 'user_id',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type Faq_manualScalarFieldEnum = (typeof Faq_manualScalarFieldEnum)[keyof typeof Faq_manualScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const Chat_historyOrderByRelevanceFieldEnum: {
    chat_id: 'chat_id',
    user_id: 'user_id',
    user_message: 'user_message',
    retrieved_context: 'retrieved_context',
    bot_response: 'bot_response'
  };

  export type Chat_historyOrderByRelevanceFieldEnum = (typeof Chat_historyOrderByRelevanceFieldEnum)[keyof typeof Chat_historyOrderByRelevanceFieldEnum]


  export const Faq_manualOrderByRelevanceFieldEnum: {
    faq_id: 'faq_id',
    question: 'question',
    answer: 'answer',
    kategori: 'kategori',
    reference: 'reference',
    user_id: 'user_id'
  };

  export type Faq_manualOrderByRelevanceFieldEnum = (typeof Faq_manualOrderByRelevanceFieldEnum)[keyof typeof Faq_manualOrderByRelevanceFieldEnum]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    
  /**
   * Deep Input Types
   */


  export type Chat_historyWhereInput = {
    AND?: Chat_historyWhereInput | Chat_historyWhereInput[]
    OR?: Chat_historyWhereInput[]
    NOT?: Chat_historyWhereInput | Chat_historyWhereInput[]
    chat_id?: StringFilter<"Chat_history"> | string
    user_id?: StringFilter<"Chat_history"> | string
    user_message?: StringFilter<"Chat_history"> | string
    retrieved_context?: StringFilter<"Chat_history"> | string
    bot_response?: StringFilter<"Chat_history"> | string
    created_at?: DateTimeFilter<"Chat_history"> | Date | string
    updated_at?: DateTimeFilter<"Chat_history"> | Date | string
  }

  export type Chat_historyOrderByWithRelationInput = {
    chat_id?: SortOrder
    user_id?: SortOrder
    user_message?: SortOrder
    retrieved_context?: SortOrder
    bot_response?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    _relevance?: Chat_historyOrderByRelevanceInput
  }

  export type Chat_historyWhereUniqueInput = Prisma.AtLeast<{
    chat_id?: string
    AND?: Chat_historyWhereInput | Chat_historyWhereInput[]
    OR?: Chat_historyWhereInput[]
    NOT?: Chat_historyWhereInput | Chat_historyWhereInput[]
    user_id?: StringFilter<"Chat_history"> | string
    user_message?: StringFilter<"Chat_history"> | string
    retrieved_context?: StringFilter<"Chat_history"> | string
    bot_response?: StringFilter<"Chat_history"> | string
    created_at?: DateTimeFilter<"Chat_history"> | Date | string
    updated_at?: DateTimeFilter<"Chat_history"> | Date | string
  }, "chat_id">

  export type Chat_historyOrderByWithAggregationInput = {
    chat_id?: SortOrder
    user_id?: SortOrder
    user_message?: SortOrder
    retrieved_context?: SortOrder
    bot_response?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    _count?: Chat_historyCountOrderByAggregateInput
    _max?: Chat_historyMaxOrderByAggregateInput
    _min?: Chat_historyMinOrderByAggregateInput
  }

  export type Chat_historyScalarWhereWithAggregatesInput = {
    AND?: Chat_historyScalarWhereWithAggregatesInput | Chat_historyScalarWhereWithAggregatesInput[]
    OR?: Chat_historyScalarWhereWithAggregatesInput[]
    NOT?: Chat_historyScalarWhereWithAggregatesInput | Chat_historyScalarWhereWithAggregatesInput[]
    chat_id?: StringWithAggregatesFilter<"Chat_history"> | string
    user_id?: StringWithAggregatesFilter<"Chat_history"> | string
    user_message?: StringWithAggregatesFilter<"Chat_history"> | string
    retrieved_context?: StringWithAggregatesFilter<"Chat_history"> | string
    bot_response?: StringWithAggregatesFilter<"Chat_history"> | string
    created_at?: DateTimeWithAggregatesFilter<"Chat_history"> | Date | string
    updated_at?: DateTimeWithAggregatesFilter<"Chat_history"> | Date | string
  }

  export type Faq_manualWhereInput = {
    AND?: Faq_manualWhereInput | Faq_manualWhereInput[]
    OR?: Faq_manualWhereInput[]
    NOT?: Faq_manualWhereInput | Faq_manualWhereInput[]
    faq_id?: StringFilter<"Faq_manual"> | string
    question?: StringFilter<"Faq_manual"> | string
    answer?: StringFilter<"Faq_manual"> | string
    kategori?: StringFilter<"Faq_manual"> | string
    reference?: StringFilter<"Faq_manual"> | string
    user_id?: StringFilter<"Faq_manual"> | string
    created_at?: DateTimeFilter<"Faq_manual"> | Date | string
    updated_at?: DateTimeFilter<"Faq_manual"> | Date | string
  }

  export type Faq_manualOrderByWithRelationInput = {
    faq_id?: SortOrder
    question?: SortOrder
    answer?: SortOrder
    kategori?: SortOrder
    reference?: SortOrder
    user_id?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    _relevance?: Faq_manualOrderByRelevanceInput
  }

  export type Faq_manualWhereUniqueInput = Prisma.AtLeast<{
    faq_id?: string
    AND?: Faq_manualWhereInput | Faq_manualWhereInput[]
    OR?: Faq_manualWhereInput[]
    NOT?: Faq_manualWhereInput | Faq_manualWhereInput[]
    question?: StringFilter<"Faq_manual"> | string
    answer?: StringFilter<"Faq_manual"> | string
    kategori?: StringFilter<"Faq_manual"> | string
    reference?: StringFilter<"Faq_manual"> | string
    user_id?: StringFilter<"Faq_manual"> | string
    created_at?: DateTimeFilter<"Faq_manual"> | Date | string
    updated_at?: DateTimeFilter<"Faq_manual"> | Date | string
  }, "faq_id">

  export type Faq_manualOrderByWithAggregationInput = {
    faq_id?: SortOrder
    question?: SortOrder
    answer?: SortOrder
    kategori?: SortOrder
    reference?: SortOrder
    user_id?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    _count?: Faq_manualCountOrderByAggregateInput
    _max?: Faq_manualMaxOrderByAggregateInput
    _min?: Faq_manualMinOrderByAggregateInput
  }

  export type Faq_manualScalarWhereWithAggregatesInput = {
    AND?: Faq_manualScalarWhereWithAggregatesInput | Faq_manualScalarWhereWithAggregatesInput[]
    OR?: Faq_manualScalarWhereWithAggregatesInput[]
    NOT?: Faq_manualScalarWhereWithAggregatesInput | Faq_manualScalarWhereWithAggregatesInput[]
    faq_id?: StringWithAggregatesFilter<"Faq_manual"> | string
    question?: StringWithAggregatesFilter<"Faq_manual"> | string
    answer?: StringWithAggregatesFilter<"Faq_manual"> | string
    kategori?: StringWithAggregatesFilter<"Faq_manual"> | string
    reference?: StringWithAggregatesFilter<"Faq_manual"> | string
    user_id?: StringWithAggregatesFilter<"Faq_manual"> | string
    created_at?: DateTimeWithAggregatesFilter<"Faq_manual"> | Date | string
    updated_at?: DateTimeWithAggregatesFilter<"Faq_manual"> | Date | string
  }

  export type Chat_historyCreateInput = {
    chat_id?: string
    user_id: string
    user_message: string
    retrieved_context: string
    bot_response: string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type Chat_historyUncheckedCreateInput = {
    chat_id?: string
    user_id: string
    user_message: string
    retrieved_context: string
    bot_response: string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type Chat_historyUpdateInput = {
    chat_id?: StringFieldUpdateOperationsInput | string
    user_id?: StringFieldUpdateOperationsInput | string
    user_message?: StringFieldUpdateOperationsInput | string
    retrieved_context?: StringFieldUpdateOperationsInput | string
    bot_response?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type Chat_historyUncheckedUpdateInput = {
    chat_id?: StringFieldUpdateOperationsInput | string
    user_id?: StringFieldUpdateOperationsInput | string
    user_message?: StringFieldUpdateOperationsInput | string
    retrieved_context?: StringFieldUpdateOperationsInput | string
    bot_response?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type Chat_historyCreateManyInput = {
    chat_id?: string
    user_id: string
    user_message: string
    retrieved_context: string
    bot_response: string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type Chat_historyUpdateManyMutationInput = {
    chat_id?: StringFieldUpdateOperationsInput | string
    user_id?: StringFieldUpdateOperationsInput | string
    user_message?: StringFieldUpdateOperationsInput | string
    retrieved_context?: StringFieldUpdateOperationsInput | string
    bot_response?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type Chat_historyUncheckedUpdateManyInput = {
    chat_id?: StringFieldUpdateOperationsInput | string
    user_id?: StringFieldUpdateOperationsInput | string
    user_message?: StringFieldUpdateOperationsInput | string
    retrieved_context?: StringFieldUpdateOperationsInput | string
    bot_response?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type Faq_manualCreateInput = {
    faq_id?: string
    question: string
    answer: string
    kategori: string
    reference: string
    user_id: string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type Faq_manualUncheckedCreateInput = {
    faq_id?: string
    question: string
    answer: string
    kategori: string
    reference: string
    user_id: string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type Faq_manualUpdateInput = {
    faq_id?: StringFieldUpdateOperationsInput | string
    question?: StringFieldUpdateOperationsInput | string
    answer?: StringFieldUpdateOperationsInput | string
    kategori?: StringFieldUpdateOperationsInput | string
    reference?: StringFieldUpdateOperationsInput | string
    user_id?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type Faq_manualUncheckedUpdateInput = {
    faq_id?: StringFieldUpdateOperationsInput | string
    question?: StringFieldUpdateOperationsInput | string
    answer?: StringFieldUpdateOperationsInput | string
    kategori?: StringFieldUpdateOperationsInput | string
    reference?: StringFieldUpdateOperationsInput | string
    user_id?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type Faq_manualCreateManyInput = {
    faq_id?: string
    question: string
    answer: string
    kategori: string
    reference: string
    user_id: string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type Faq_manualUpdateManyMutationInput = {
    faq_id?: StringFieldUpdateOperationsInput | string
    question?: StringFieldUpdateOperationsInput | string
    answer?: StringFieldUpdateOperationsInput | string
    kategori?: StringFieldUpdateOperationsInput | string
    reference?: StringFieldUpdateOperationsInput | string
    user_id?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type Faq_manualUncheckedUpdateManyInput = {
    faq_id?: StringFieldUpdateOperationsInput | string
    question?: StringFieldUpdateOperationsInput | string
    answer?: StringFieldUpdateOperationsInput | string
    kategori?: StringFieldUpdateOperationsInput | string
    reference?: StringFieldUpdateOperationsInput | string
    user_id?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type Chat_historyOrderByRelevanceInput = {
    fields: Chat_historyOrderByRelevanceFieldEnum | Chat_historyOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type Chat_historyCountOrderByAggregateInput = {
    chat_id?: SortOrder
    user_id?: SortOrder
    user_message?: SortOrder
    retrieved_context?: SortOrder
    bot_response?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type Chat_historyMaxOrderByAggregateInput = {
    chat_id?: SortOrder
    user_id?: SortOrder
    user_message?: SortOrder
    retrieved_context?: SortOrder
    bot_response?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type Chat_historyMinOrderByAggregateInput = {
    chat_id?: SortOrder
    user_id?: SortOrder
    user_message?: SortOrder
    retrieved_context?: SortOrder
    bot_response?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type Faq_manualOrderByRelevanceInput = {
    fields: Faq_manualOrderByRelevanceFieldEnum | Faq_manualOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type Faq_manualCountOrderByAggregateInput = {
    faq_id?: SortOrder
    question?: SortOrder
    answer?: SortOrder
    kategori?: SortOrder
    reference?: SortOrder
    user_id?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type Faq_manualMaxOrderByAggregateInput = {
    faq_id?: SortOrder
    question?: SortOrder
    answer?: SortOrder
    kategori?: SortOrder
    reference?: SortOrder
    user_id?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type Faq_manualMinOrderByAggregateInput = {
    faq_id?: SortOrder
    question?: SortOrder
    answer?: SortOrder
    kategori?: SortOrder
    reference?: SortOrder
    user_id?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}